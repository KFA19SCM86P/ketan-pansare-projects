const Details = new Mongo.Collection(null);
Details.insert({ id: '', detail: {} });
export default Details;
