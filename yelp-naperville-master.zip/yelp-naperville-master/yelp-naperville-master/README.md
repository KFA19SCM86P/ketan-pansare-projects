SO I have completed the Assignment 
To run the assignment:
Use the command : meteor --settings settings.json
Why this command because we need to set the ENV variable for the Public-Key 
which should not be seen by the common person.
The moment we use this command we don't need to use meteor seperately and it starts running the app and 